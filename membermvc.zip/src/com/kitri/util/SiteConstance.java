package com.kitri.util;

public class SiteConstance {
	
	public static final String ENCODE = "UTF-8";
	
//	DB info
	public static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String DB_URL = "jdbc:oracle:thin:@192.168.14.52:1521:orcl";
	public static final String DB_USERNAME = "kitri";
	public static final String DB_PASSWORD = "kitri";

}

package com.kitri.admin.model.service;

public interface AdminService {

	public String getMemberList(String key, String word);
	
}
